# Custom arrows in Slick slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/porsake/pen/NWqYKZd](https://codepen.io/porsake/pen/NWqYKZd).

