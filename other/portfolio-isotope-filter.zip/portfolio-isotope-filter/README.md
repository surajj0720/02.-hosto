# Portfolio Isotope Filter

A Pen created on CodePen.io. Original URL: [https://codepen.io/aylinmarie/pen/NjwOGv](https://codepen.io/aylinmarie/pen/NjwOGv).

